#!/usr/bin/env pwsh
<#
.SYNOPSIS
    Deploy Ransomware incident response and recovery Package

.DESCRIPTION
    Automated deployment script for the Ransomware incident response and recovery incident response package.
    This script deploys Velociraptor with pre-configured artifacts and tools for this specific
    incident response scenario.

.PARAMETER InstallDir
    Installation directory for Velociraptor

.PARAMETER ConfigFile
    Configuration file to use

.PARAMETER Offline
    Run in offline mode using bundled tools

.EXAMPLE
    .\Deploy-Ransomware.ps1 -InstallDir "C:\Velociraptor" -Offline
#>

[CmdletBinding()]
param(
    [string]$InstallDir = "C:\Program Files\Velociraptor",
    [string]$ConfigFile = "config\ransomware-config.yaml",
    [switch]$Offline
)

Write-Host "🚀 Deploying Ransomware incident response and recovery Package" -ForegroundColor Green
Write-Host "📁 Installation Directory: $InstallDir" -ForegroundColor Cyan
Write-Host "⚙️ Configuration: $ConfigFile" -ForegroundColor Cyan
Write-Host "🌐 Offline Mode: $Offline" -ForegroundColor Cyan

# Set tool paths for offline mode
if ($Offline) {
    $env:VELOCIRAPTOR_TOOLS_PATH = Join-Path $PSScriptRoot "tools"
    Write-Host "🔧 Using offline tools from: $($env:VELOCIRAPTOR_TOOLS_PATH)" -ForegroundColor Yellow
}

# Import the main deployment module
Import-Module .\VelociraptorSetupScripts.psd1 -Force -ErrorAction SilentlyContinue

# Deploy based on configuration
if (Test-Path $ConfigFile) {
    Deploy-VelociraptorServer -InstallDir $InstallDir -ConfigPath $ConfigFile -Force -ErrorAction SilentlyContinue
} else {
    Write-Warning "Configuration file not found: $ConfigFile"
    Write-Information "Using default deployment..." -InformationAction Continue
    Deploy-VelociraptorServer -InstallDir $InstallDir -Force -ErrorAction SilentlyContinue
}

Write-Host "✅ Ransomware incident response and recovery package deployment completed!" -ForegroundColor Green
