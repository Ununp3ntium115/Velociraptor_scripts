#!/usr/bin/env pwsh
<#
.SYNOPSIS
    Deploy Insider threat investigation Package

.DESCRIPTION
    Automated deployment script for the Insider threat investigation incident response package.
    This script deploys Velociraptor with pre-configured artifacts and tools for this specific
    incident response scenario.

.PARAMETER InstallDir
    Installation directory for Velociraptor

.PARAMETER ConfigFile
    Configuration file to use

.PARAMETER Offline
    Run in offline mode using bundled tools

.EXAMPLE
    .\Deploy-Insider.ps1 -InstallDir "C:\Velociraptor" -Offline
#>

[CmdletBinding()]
param(
    [string]$InstallDir = "C:\Program Files\Velociraptor",
    [string]$ConfigFile = "config\insider-config.yaml",
    [switch]$Offline
)

Write-Host "🚀 Deploying Insider threat investigation Package" -ForegroundColor Green
Write-Host "📁 Installation Directory: $InstallDir" -ForegroundColor Cyan
Write-Host "⚙️ Configuration: $ConfigFile" -ForegroundColor Cyan
Write-Host "🌐 Offline Mode: $Offline" -ForegroundColor Cyan

# Set tool paths for offline mode
if ($Offline) {
    $env:VELOCIRAPTOR_TOOLS_PATH = Join-Path $PSScriptRoot "tools"
    Write-Host "🔧 Using offline tools from: $($env:VELOCIRAPTOR_TOOLS_PATH)" -ForegroundColor Yellow
}

# Import the main deployment module
Import-Module .\VelociraptorSetupScripts.psd1 -Force -ErrorAction SilentlyContinue

# Deploy based on configuration
if (Test-Path $ConfigFile) {
    Deploy-VelociraptorServer -InstallDir $InstallDir -ConfigPath $ConfigFile -Force -ErrorAction SilentlyContinue
} else {
    Write-Warning "Configuration file not found: $ConfigFile"
    Write-Information "Using default deployment..." -InformationAction Continue
    Deploy-VelociraptorServer -InstallDir $InstallDir -Force -ErrorAction SilentlyContinue
}

Write-Host "✅ Insider threat investigation package deployment completed!" -ForegroundColor Green
