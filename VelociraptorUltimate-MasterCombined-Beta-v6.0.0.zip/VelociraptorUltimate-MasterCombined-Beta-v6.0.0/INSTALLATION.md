# 🚀 Installation Guide - VelociraptorUltimate Master Combined

## Prerequisites

### System Requirements
- **Operating System**: Windows 10/11 or Windows Server 2016+
- **PowerShell**: Version 5.1 or later (PowerShell Core 7.0+ supported)
- **Privileges**: Administrator access required
- **Memory**: 4GB RAM minimum (8GB recommended)
- **Storage**: 10GB free disk space
- **Network**: Internet connection for downloads

### Pre-Installation Checklist
- [ ] Verify Administrator privileges
- [ ] Ensure PowerShell execution policy allows scripts
- [ ] Check available disk space (10GB minimum)
- [ ] Verify internet connectivity
- [ ] Close any existing Velociraptor instances

## Installation Methods

### Method 1: Quick Start (Recommended)
1. **Extract Package**: Unzip to desired location (e.g., C:\VelociraptorUltimate)
2. **Run as Administrator**: Right-click Start-VelociraptorUltimate-Master.bat
3. **Select "Run as administrator"**
4. **Follow GUI prompts**: Use the Installation Wizard tab

### Method 2: PowerShell Launch
1. **Open PowerShell as Administrator**
2. **Navigate to directory**: cd C:\VelociraptorUltimate
3. **Run launcher**: .\Start-VelociraptorUltimate-Master.ps1
4. **Optional mode selection**: Add -StartMode Advanced for specific tab

### Method 3: Direct Execution
1. **Open PowerShell as Administrator**
2. **Navigate to directory**: cd C:\VelociraptorUltimate
3. **Run main script**: .\VelociraptorUltimate-MASTER-COMBINED.ps1
4. **Configure as needed**: Use GUI tabs for configuration

## First-Time Setup

### Step 1: Launch Application
- Use any installation method above
- Verify the GUI opens with 4 tabs:
  - 🧙‍♂️ Installation Wizard
  - 🚀 Advanced Deployment
  - 📊 Monitoring
  - 🔧 Third-Party Tools

### Step 2: Install Velociraptor
- **For beginners**: Use "Installation Wizard" tab
- **For advanced users**: Use "Advanced Deployment" tab
- **Select deployment mode**: Standalone (recommended for first-time)
- **Follow 8-step process**: Automated configuration and setup

### Step 3: Verify Installation
- Check "Monitoring" tab for system status
- Verify web GUI accessibility at https://127.0.0.1:8889
- Test user login (default: admin/admin123)

### Step 4: Install DFIR Tools (Optional)
- Navigate to "Third-Party Tools" tab
- Select desired tool categories
- Click "Install All Selected"
- Verify integration with Velociraptor

## Configuration

### Basic Configuration
- **Installation Path**: Default C:\tools (customizable)
- **GUI Port**: Default 8889 (customizable)
- **Authentication**: Basic auth with admin/admin123
- **SSL**: Auto-generated self-signed certificates

### Advanced Configuration
- **Server Mode**: Multi-client enterprise deployment
- **Security Hardening**: Zero Trust security model
- **Compliance**: SOX, HIPAA, PCI-DSS, GDPR frameworks
- **Monitoring**: Real-time health monitoring
- **Tool Integration**: Automatic DFIR tools integration

### Custom Configuration Files
- **Server Config**: config/server-template.yaml
- **Tools Config**: config/third-party-tools.json
- **Backup Location**: ackup/ directory
- **Logs Location**: logs/ directory

## Verification Steps

### 1. Process Check
`powershell
Get-Process | Where-Object {.ProcessName -like "*velociraptor*"}
`

### 2. Port Check
`powershell
netstat -an | findstr :8889
`

### 3. Web Interface Test
- Open browser to https://127.0.0.1:8889
- Login with admin/admin123
- Verify dashboard loads

### 4. Tool Integration Check
- Navigate to Third-Party Tools tab
- Verify installed tools list
- Check integration status

## Troubleshooting

### Common Issues

#### "Access Denied" Error
- **Cause**: Not running as Administrator
- **Solution**: Right-click and "Run as administrator"

#### "Port Already in Use"
- **Cause**: Existing Velociraptor instance running
- **Solution**: Stop existing process or use different port

#### "Binary Not Found"
- **Cause**: Velociraptor binary not downloaded
- **Solution**: Use "Download Latest" option in deployment

#### "Web GUI Not Accessible"
- **Cause**: Firewall blocking port 8889
- **Solution**: Add firewall exception or use different port

### Advanced Troubleshooting

#### Check Logs
- Application logs: logs/VelociraptorUltimate-Master.log
- Velociraptor logs: Check Monitoring tab
- System logs: Windows Event Viewer

#### Configuration Reset
- Delete configuration files in config/
- Restart application
- Reconfigure using Installation Wizard

#### Clean Installation
- Stop all Velociraptor processes
- Delete installation directory
- Re-extract package
- Start fresh installation

## Post-Installation

### Security Hardening
1. **Change Default Password**: Replace admin/admin123
2. **Configure SSL**: Use proper certificates for production
3. **Enable Compliance**: Apply relevant frameworks
4. **Setup Monitoring**: Configure health checks

### Tool Integration
1. **Install DFIR Tools**: Use Third-Party Tools tab
2. **Create Artifacts**: Enable automatic artifact creation
3. **Configure Paths**: Add tools to system PATH
4. **Test Integration**: Verify tools work with Velociraptor

### Backup Configuration
1. **Export Settings**: Use configuration export features
2. **Backup Files**: Copy config/ and ackup/ directories
3. **Document Changes**: Maintain change log
4. **Test Restore**: Verify backup restoration process

## Support and Resources

### Getting Help
- **Status Monitoring**: Use Monitoring tab for real-time status
- **Configuration Testing**: Use "Test Configuration" before deployment
- **Log Analysis**: Check application and system logs
- **Documentation**: Refer to README.md and CHANGELOG.md

### Best Practices
- Always run as Administrator
- Test configuration before production deployment
- Regularly backup configurations
- Monitor system status and logs
- Keep tools and artifacts updated

---

**🦖 Ready to deploy your complete DFIR platform!**
