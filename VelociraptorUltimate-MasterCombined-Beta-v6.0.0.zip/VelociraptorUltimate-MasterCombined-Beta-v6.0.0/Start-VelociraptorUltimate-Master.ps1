#Requires -RunAsAdministrator

<#
.SYNOPSIS
    VelociraptorUltimate Master Combined Launcher

.DESCRIPTION
    Launches the VelociraptorUltimate Master Combined GUI with all features:
    - Step-by-Step Installation Wizard
    - Advanced Deployment (5 modes)
    - Real-time Monitoring
    - Third-Party Tools Management
#>

param(
    [Parameter(HelpMessage="Start in specific mode")]
    [ValidateSet("Wizard", "Advanced", "Monitoring", "Tools")]
    [string] = "Wizard"
)

# Set location to script directory
Set-Location $PSScriptRoot

# Launch the main application
try {
    & ".\VelociraptorUltimate-MASTER-COMBINED.ps1" -StartMode $StartMode
}
catch {
    Write-Error "Failed to launch VelociraptorUltimate Master Combined: $($_.Exception.Message)"
    Read-Host "Press Enter to exit"
}
