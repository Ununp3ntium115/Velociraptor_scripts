# 🦖 VelociraptorUltimate Master Combined v6.0.0-MASTER-DARK

The ultimate all-in-one Velociraptor deployment and management interface with comprehensive third-party DFIR tools integration.

## 🚀 Quick Start

### Option 1: Batch File (Recommended)
1. Right-click Start-VelociraptorUltimate-Master.bat
2. Select "Run as administrator"
3. The GUI will launch automatically

### Option 2: PowerShell
1. Open PowerShell as Administrator
2. Navigate to this directory
3. Run: .\Start-VelociraptorUltimate-Master.ps1

### Option 3: Direct Launch
1. Open PowerShell as Administrator
2. Run: .\VelociraptorUltimate-MASTER-COMBINED.ps1

## ✨ Features

### 🧙‍♂️ Installation Wizard
- **8-Step Process**: Binary → Config → Certificates → Auth → Storage → Service → GUI → Client
- **Real-time Progress**: Live progress bar and detailed logging
- **Automatic Configuration**: DNS, SSL, and authentication setup
- **Proven Methods**: Uses [WORKING-CMD] for reliable deployment

### 🚀 Advanced Deployment
- **5 Deployment Modes**:
  - 🖥️ **Standalone** - Single machine (ready for immediate deployment)
  - 🏢 **Server** - Multi-client enterprise deployment
  - 🌐 **Cluster** - High availability with load balancing
  - ☁️ **Cloud** - AWS/Azure/GCP deployment
  - 🐳 **Container** - Docker/Kubernetes deployment
- **Configuration Testing**: Pre-deployment validation
- **Multiple Binary Sources**: Download, existing, custom path, build from source

### 📊 Real-time Monitoring
- **System Status**: Process, port, web GUI, binary status
- **Performance Metrics**: CPU, memory, uptime, connections
- **Live Logging**: Real-time log viewer with filtering
- **Health Checks**: Automated status monitoring

### 🔧 Third-Party Tools Management
- **8 Tool Categories**:
  - 🧠 **Memory Analysis** - Volatility, Rekall
  - 💽 **Disk Forensics** - Autopsy, TSK, FTK Imager
  - 🦠 **Malware Analysis** - YARA, Cuckoo, REMnux
  - 🌐 **Network Analysis** - Wireshark, NetworkMiner
  - ⏰ **Timeline Analysis** - Plaso, Log2Timeline
  - 📊 **System Monitoring** - OSQuery, Sysmon
  - 📝 **Log Analysis** - Sigma, Splunk, ELK Stack
  - 🎯 **Threat Intelligence** - MISP, OpenCTI

### 🔗 Velociraptor Integration
- **Auto-Integration**: Seamless tool integration with Velociraptor
- **Artifact Creation**: Generate Velociraptor artifacts for each tool
- **PATH Integration**: Add tools to system PATH
- **Context Menus**: Right-click integration
- **Centralized Management**: Single interface for all tools

## 🎯 Usage Scenarios

### For New Users
1. Start with the **Installation Wizard** tab
2. Use **Standalone** deployment mode
3. Follow the 8-step guided process
4. Access web GUI at https://127.0.0.1:8889

### For Enterprise Deployment
1. Use **Advanced Deployment** tab
2. Select **Server** mode
3. Configure security hardening and compliance
4. Enable health monitoring
5. Install third-party tools for complete DFIR capability

### For DFIR Teams
1. Deploy Velociraptor using **Server** mode
2. Use **Third-Party Tools** tab to install forensics toolkit
3. Enable auto-integration for seamless workflow
4. Monitor everything from the **Monitoring** tab

## 📁 Directory Structure

`
VelociraptorUltimate-MasterCombined-Beta-v6.0.0/
├── VelociraptorUltimate-MASTER-COMBINED.ps1    # Main GUI application
├── Start-VelociraptorUltimate-Master.bat       # Batch launcher
├── Start-VelociraptorUltimate-Master.ps1       # PowerShell launcher
├── scripts/                                    # Essential scripts
│   ├── deployment/                             # Deployment scripts
│   ├── user-management/                        # User management
│   ├── testing/                                # QA/UA testing
│   ├── configuration/                          # Config management
│   ├── tools/                                  # Third-party tools
│   └── security/                               # Security framework
├── config/                                     # Configuration templates
├── templates/                                  # Deployment templates
├── tools/                                      # Third-party tools
├── artifacts/                                  # Custom artifacts
├── logs/                                       # Application logs
├── backup/                                     # Configuration backups
└── documentation/                              # Additional docs
`

## ⚙️ Configuration

### Third-Party Tools
Edit config/third-party-tools.json to customize tool installation:
- Installation path
- Auto-integration settings
- Tool categories to install
- Velociraptor artifact creation

### Velociraptor Server
Edit config/server-template.yaml for server configuration:
- Bind addresses and ports
- SSL/TLS settings
- Datastore configuration
- Tool integration paths

## 🛡️ Security Features

- **Zero Trust Security**: Advanced security hardening
- **Compliance Frameworks**: SOX, HIPAA, PCI-DSS, GDPR
- **SSL/TLS**: Automatic certificate generation
- **User Management**: Role-based access control
- **Audit Logging**: Comprehensive security logging

## 🔧 Troubleshooting

### Common Issues
1. **"Access Denied"**: Run as Administrator
2. **"Port in use"**: Check if Velociraptor is already running
3. **"Binary not found"**: Use "Download Latest" option
4. **"Web GUI not accessible"**: Check firewall settings

### Getting Help
1. Check the **Monitoring** tab for system status
2. Use **Test Configuration** before deployment
3. Review logs in the logs/ directory
4. Check the status display in each tab

## 📊 System Requirements

- **OS**: Windows 10/11, Windows Server 2016+
- **PowerShell**: 5.1+ or PowerShell Core 7.0+
- **Privileges**: Administrator required
- **Memory**: 4GB RAM minimum, 8GB recommended
- **Disk**: 10GB free space for tools and data
- **Network**: Internet access for tool downloads

## 🎉 What's New in v6.0.0-MASTER-DARK

- **🌙 Dark Theme**: Professional dark interface
- **🔧 Third-Party Tools**: Comprehensive DFIR tools management
- **🚀 Advanced Deployment**: 5 deployment modes
- **📊 Enhanced Monitoring**: Real-time status and performance
- **🔗 Tool Integration**: Seamless Velociraptor integration
- **⚙️ Configuration Management**: Export/import configurations
- **🛡️ Security Framework**: Enterprise-grade security
- **📱 Responsive Design**: Larger, resizable interface

## 📞 Support

For issues, questions, or contributions:
- Review the comprehensive logging in each tab
- Check system status in the Monitoring tab
- Use configuration testing before deployment
- Refer to the Velociraptor documentation for advanced topics

---

**🦖 VelociraptorUltimate Master Combined - The complete DFIR platform management solution**
